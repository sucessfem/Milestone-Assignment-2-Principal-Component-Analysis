from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import numpy as np

# Step 1: Load the relevant cancer data
cancer_data = load_breast_cancer()
features = cancer_data.data
labels = cancer_data.target

# Step 2: Utilize PCA
model = PCA()
transformed_features = model.fit_transform(features)

# Step 3: For each component, display the variance ratio
print("Variance Ratios:")
print(model.explained_variance_ratio_)

# Step 4: Display the Cummulative Variance ratios
cumulative_var_ratio = np.cumsum(model.explained_variance_ratio_)
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(cumulative_var_ratio) + 1), cumulative_var_ratio, 'bo-')
plt.xlabel('Count of Principal Components')
plt.ylabel('Total Explained Variance')
plt.title('Total Explained Variance vs. Count of Principal Components')
plt.grid(True)
plt.show()

# Step 5: Reducing to 2 PCA Components
pca_2 = PCA(n_components=2)
new_features = pca_2.fit_transform(features)

# Step 6:  Partition data for training and testing
x_train, x_test, y_train, y_test = train_test_split(new_features, labels, test_size=0.2, random_state=42)

# Step 7: Logistic Regression
logistic_regression = LogisticRegression(random_state=42)
logistic_regression.fit(x_train, y_train)

# Step 8: Generate predictions
predictions = logistic_regression.predict(x_test)

# Step 9: Evaluate performance
accuracy = accuracy_score(y_test, predictions)
print(f"Model Accuracy: {accuracy:.4f}")
